#!/bin/sh
echo $0 $*
progdir=`dirname "$0"`
cd $progdir
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$progdir
#export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/trimui/lib:$progdir
#HOME=progdir $progdir/retroarch -v

#./onscripter --fullscreen
./onscripter
